#!/usr/bin/env bash
echo 'Install NebulaMon'