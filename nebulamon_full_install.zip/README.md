# NebulaMon
Self‑Hosted Monitoring für Linux‑Hosts über SSH (agentlos).