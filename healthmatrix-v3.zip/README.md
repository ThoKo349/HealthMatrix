# HealthMatrix
Self‑Hosted Monitoring (CPU, RAM, Disk, SSH Pull).