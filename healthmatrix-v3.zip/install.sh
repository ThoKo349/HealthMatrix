#!/usr/bin/env bash
set -euo pipefail
APP_USER="healthmatrix"
APP_DIR="/opt/healthmatrix"
PY_BIN="python3"
if [[ $EUID -ne 0 ]]; then echo "Bitte als root ausführen"; exit 1; fi
apt-get update && apt-get install -y ${PY_BIN} ${PY_BIN}-venv git curl openssl
id -u "$APP_USER" >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_DIR"
cp -r . "$APP_DIR"
cd "$APP_DIR"
${PY_BIN} -m venv .venv
source .venv/bin/activate
pip install --upgrade pip wheel
pip install -r requirements.txt
if [[ ! -f .env ]]; then
  SECRET=$(openssl rand -hex 32)
  cat > .env <<EOF
SECRET_KEY=$SECRET
DB_URL=sqlite:///./healthmatrix.db
BIND_HOST=0.0.0.0
BIND_PORT=8080
EOF
  chown $APP_USER:$APP_USER .env
fi
cat >/etc/systemd/system/healthmatrix.service <<'UNIT'
[Unit]
Description=HealthMatrix Monitoring Service
After=network.target

[Service]
User=healthmatrix
WorkingDirectory=/opt/healthmatrix
EnvironmentFile=/opt/healthmatrix/.env
ExecStart=/opt/healthmatrix/.venv/bin/uvicorn app.main:app --host ${BIND_HOST} --port ${BIND_PORT}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
chown -R $APP_USER:$APP_USER "$APP_DIR"
systemctl daemon-reload
systemctl enable --now healthmatrix.service
echo "HealthMatrix läuft auf http://$(hostname -I | awk '{print $1}'):${BIND_PORT:-8080}"
