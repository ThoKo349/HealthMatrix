#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<USAGE
Usage: $0 [--dev] [--systemd] [--port PORT] [--bind HOST] [--admin-user USER] [--admin-pass PASS]
  --dev         Nur lokale Umgebung (venv + pip). Start per 'python app.py' manuell.
  --systemd     Installiere/aktiviere systemd-Dienst 'ssh-admin.service' (Port 8080 default).
  --port PORT   APP_PORT (default 8080)
  --bind HOST   APP_BIND (default 0.0.0.0)
  --admin-user  Login-User für die Webapp (default admin)
  --admin-pass  Login-Passwort für die Webapp (default change-me)
USAGE
}

DEV=0
SYSTEMD=0
PORT=${APP_PORT:-8080}
BIND=${APP_BIND:-0.0.0.0}
ADMIN_USER=${APP_ADMIN_USERNAME:-admin}
ADMIN_PASS=${APP_ADMIN_PASSWORD:-change-me}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dev) DEV=1; shift;;
    --systemd) SYSTEMD=1; shift;;
    --port) PORT="$2"; shift 2;;
    --bind) BIND="$2"; shift 2;;
    --admin-user) ADMIN_USER="$2"; shift 2;;
    --admin-pass) ADMIN_PASS="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

# 1) Basics
if ! command -v python3 >/dev/null 2>&1; then
  sudo apt update && sudo apt install -y python3
fi
if ! python3 -c "import venv" 2>/dev/null; then
  sudo apt install -y python3-venv
fi
if ! command -v pip >/dev/null 2>&1; then
  sudo apt install -y python3-pip
fi

# 2) venv + deps
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# 3) .env erstellen, falls fehlt
if [[ ! -f .env ]]; then
  FERNET_KEY=$(python3 - <<'PY'
from cryptography.fernet import Fernet
print(Fernet.generate_key().decode())
PY
)
  FLASK_SECRET=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)
  cat > .env <<ENV
FLASK_SECRET=${FLASK_SECRET}
FERNET_KEY=${FERNET_KEY}
APP_ADMIN_USERNAME=${ADMIN_USER}
APP_ADMIN_PASSWORD=${ADMIN_PASS}
APP_BIND=${BIND}
APP_PORT=${PORT}
DATABASE_URL=sqlite:///data.db
ENV
  echo "Created .env with default values. Bitte prüfe/ändere sie bei Bedarf."
fi

if [[ ${DEV} -eq 1 && ${SYSTEMD} -eq 0 ]]; then
  echo "Dev-Setup fertig. Starte mit: source .venv/bin/activate && python app.py"
  exit 0
fi

# 4) systemd service
if [[ ${SYSTEMD} -eq 1 ]]; then
  if ! command -v systemctl >/dev/null 2>&1; then
    echo "systemd nicht gefunden. Läuft dein LXC mit systemd?"
    exit 1
  fi
  UNIT_PATH="/etc/systemd/system/ssh-admin.service"
  EXEC="$(pwd)/.venv/bin/gunicorn"
  WORKDIR="$(pwd)"
  cat | sudo tee "${UNIT_PATH}" >/dev/null <<UNIT
[Unit]
Description=SSH Admin Webapp (Gunicorn)
After=network.target

[Service]
Type=simple
User=${USER}
WorkingDirectory=${WORKDIR}
Environment="PYTHONUNBUFFERED=1"
EnvironmentFile=${WORKDIR}/.env
ExecStart=${EXEC} -w 3 -b ${BIND}:${PORT} app:app
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT

  sudo systemctl daemon-reload
  sudo systemctl enable --now ssh-admin.service
  sudo systemctl status ssh-admin.service --no-pager || true
  echo "Systemd-Setup fertig. App läuft auf http://${BIND}:${PORT} (ggf. per Container-IP erreichbar)."
fi
