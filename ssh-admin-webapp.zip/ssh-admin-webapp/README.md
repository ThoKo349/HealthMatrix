# SSH Admin Webapp

Leichte Flask-App zum Verwalten von Linux-Hosts per SSH (Benutzer/Passwort). UI mit Tailwind + HTMX, keine komplexe Frontend-Toolchain.

## Features
- Hosts mit SSH-Zugang anlegen (Passwörter AES/Fernet-verschlüsselt).
- Preset-Aktionen pro Host & für alle: `uptime`, `df -h /`, `free -m`, `apt update (simulate)`, `reboot`.
- Session-Log Anzeige.
- App-Login via Benutzer/Passwort aus `.env`.

## Schnellstart (Entwicklung)
```bash
./install.sh --dev
# dann:
source .venv/bin/activate
python app.py
# -> http://<LXC-IP>:8080
```

## Produktion (systemd + gunicorn)
```bash
sudo ./install.sh --systemd
# -> Dienst startet auf Port 8080
```

## Sicherheit
- Ändere `.env` (Admin-Passwort, ggf. Port/Bind). Fernet-Key geheim halten.
- Für `updates`/`reboot` braucht der Remote-User passende sudoers-Rechte ohne Passwort:
  ```
  # /etc/sudoers.d/ssh-admin  (mit visudo anlegen)
  sshadmin ALL=(ALL) NOPASSWD:/usr/sbin/reboot,/usr/bin/apt-get
  ```
- In der Praxis lieber SSH-Key-Auth verwenden (Paramiko unterstützt das).

## Ordnerstruktur
```
ssh-admin-webapp/
├─ app.py
├─ requirements.txt
├─ install.sh
├─ README.md
├─ templates/
│  ├─ base.html
│  ├─ index.html
│  ├─ host_row.html
│  └─ session_log.html
└─ static/
   └─ favicon.svg
```
