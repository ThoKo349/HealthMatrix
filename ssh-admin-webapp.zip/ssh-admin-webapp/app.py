import os, sqlite3, json, datetime, socket
from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response
from cryptography.fernet import Fernet, InvalidToken
import paramiko
from dotenv import load_dotenv
from humanize import naturaltime

load_dotenv()

APP_SECRET = os.environ.get('FLASK_SECRET', os.urandom(24).hex())
FERNET_KEY = os.environ.get('FERNET_KEY')
if not FERNET_KEY:
    raise RuntimeError('FERNET_KEY nicht gesetzt (.env).')
fernet = Fernet(FERNET_KEY.encode() if not FERNET_KEY.startswith('gAAAA') else FERNET_KEY)

DB_URL = os.environ.get('DATABASE_URL', 'sqlite:///data.db')
DB_PATH = DB_URL.replace('sqlite:///','')

app = Flask(__name__)
app.secret_key = APP_SECRET

ADMIN_USER = os.environ.get('APP_ADMIN_USERNAME','admin')
ADMIN_PASS = os.environ.get('APP_ADMIN_PASSWORD','admin')

os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)

# ---------------- DB helpers ----------------

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

with db() as conn:
    conn.execute('''CREATE TABLE IF NOT EXISTS hosts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        username TEXT NOT NULL,
        password BLOB NOT NULL,
        created_at TEXT NOT NULL
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS session_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        at TEXT NOT NULL,
        host TEXT NOT NULL,
        command TEXT NOT NULL,
        output TEXT NOT NULL
    )''')
    conn.commit()

# -------------- Auth ---------------
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = request.form.get('username','')
        p = request.form.get('password','')
        if u == ADMIN_USER and p == ADMIN_PASS:
            session['auth'] = True
            return redirect(url_for('index'))
        flash('Login fehlgeschlagen', 'error')
    return make_response('''
    <html><head><meta name="viewport" content="width=device-width, initial-scale=1"><script src="https://cdn.tailwindcss.com"></script></head>
    <body class="min-h-screen flex items-center justify-center bg-slate-900 text-slate-100">
      <form method="post" class="w-full max-w-xs bg-slate-800 p-6 rounded-2xl space-y-3">
        <h1 class="text-lg font-semibold text-center">SSH Admin Login</h1>
        <input class="w-full rounded-xl bg-slate-700 px-3 py-2" name="username" placeholder="Benutzer" />
        <input class="w-full rounded-xl bg-slate-700 px-3 py-2" name="password" placeholder="Passwort" type="password" />
        <button class="w-full rounded-xl bg-emerald-600 hover:bg-emerald-500 px-3 py-2">Login</button>
      </form>
    </body></html>
    ''')

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('auth', None)
    return redirect(url_for('login'))

@app.before_request
def require_auth():
    if request.endpoint not in ('login','static') and not session.get('auth'):
        return redirect(url_for('login'))

# -------------- Utilities ---------------

def encrypt(pw: str) -> bytes:
    return fernet.encrypt(pw.encode())

def decrypt(blob: bytes) -> str:
    try:
        return fernet.decrypt(blob).decode()
    except InvalidToken:
        return ''

def ssh_exec(address, username, password, command, timeout=10):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(address, username=username, password=password, timeout=timeout, allow_agent=False, look_for_keys=False)
        stdin, stdout, stderr = client.exec_command(command)
        out = stdout.read().decode() + stderr.read().decode()
        return out.strip()
    finally:
        try:
            client.close()
        except Exception:
            pass

def log_entry(host, command, output):
    with db() as conn:
        conn.execute('INSERT INTO session_log(at,host,command,output) VALUES(?,?,?,?)', (
            datetime.datetime.utcnow().isoformat(timespec='seconds')+'Z', host, command, output
        ))
        conn.commit()

# -------------- Routes ---------------
@app.route('/')
def index():
    with db() as conn:
        hosts = [dict(r) for r in conn.execute('SELECT * FROM hosts ORDER BY id DESC').fetchall()]
        log = [dict(id=r['id'], timestamp=r['at'], host=r['host'], command=r['command'], output=r['output']) for r in conn.execute('SELECT * FROM session_log ORDER BY id DESC LIMIT 100').fetchall()][::-1]
    return render_template('index.html', hosts=hosts, session_log=log)

@app.route('/hosts', methods=['POST'])
def add_host():
    name = request.form['name'].strip()
    address = request.form['address'].strip()
    username = request.form['username'].strip()
    password = request.form['password']
    with db() as conn:
        conn.execute('INSERT INTO hosts(name,address,username,password,created_at) VALUES(?,?,?,?,?)', (
            name, address, username, encrypt(password), datetime.datetime.utcnow().isoformat(timespec='seconds')+'Z'
        ))
        conn.commit()
        host_id = conn.execute('SELECT last_insert_rowid() as id').fetchone()['id']
        h = conn.execute('SELECT * FROM hosts WHERE id=?', (host_id,)).fetchone()
    return render_template('host_row.html', h=dict(h))

@app.route('/hosts/<int:host_id>', methods=['DELETE'])
def delete_host(host_id):
    with db() as conn:
        conn.execute('DELETE FROM hosts WHERE id=?', (host_id,))
        conn.commit()
    return ('', 204)

PRESET_CMDS = {
    'uptime': 'uptime',
    'disk': 'df -h /',
    'mem': 'free -m',
    'updates': 'sudo sh -c "apt-get update && apt-get -s upgrade | head -n 40"',
    'reboot': 'sudo reboot'
}

@app.route('/hosts/<int:host_id>/action/<action>', methods=['POST'])
def run_action(host_id, action):
    if action not in PRESET_CMDS:
        return ('Unknown action', 400)
    with db() as conn:
        h = conn.execute('SELECT * FROM hosts WHERE id=?', (host_id,)).fetchone()
    if not h:
        return ('Not found', 404)
    pw = decrypt(h['password'])
    cmd = PRESET_CMDS[action]
    out = ssh_exec(h['address'], h['username'], pw, cmd)
    label = f"{h['username']}@{h['address']}"
    log_entry(label, cmd, out)
    with db() as conn:
        log = [dict(id=r['id'], timestamp=r['at'], host=r['host'], command=r['command'], output=r['output']) for r in conn.execute('SELECT * FROM session_log ORDER BY id DESC LIMIT 40').fetchall()][::-1]
    return render_template('session_log.html', session_log=log)

@app.route('/hosts/test/<int:host_id>', methods=['POST'])
def test_host(host_id):
    with db() as conn:
        h = conn.execute('SELECT * FROM hosts WHERE id=?', (host_id,)).fetchone()
    if not h:
        return ('Not found', 404)
    pw = decrypt(h['password'])
    try:
        out = ssh_exec(h['address'], h['username'], pw, 'echo OK && uname -a')
    except Exception as e:
        out = f"Fehler: {e}"
    label = f"{h['username']}@{h['address']}"
    log_entry(label, 'test', out)
    with db() as conn:
        log = [dict(id=r['id'], timestamp=r['at'], host=r['host'], command=r['command'], output=r['output']) for r in conn.execute('SELECT * FROM session_log ORDER BY id DESC LIMIT 40').fetchall()][::-1]
    return render_template('session_log.html', session_log=log)

@app.route('/run_all/<action>', methods=['POST'])
def run_all(action):
    if action not in PRESET_CMDS:
        return ('Unknown action', 400)
    with db() as conn:
        hosts = conn.execute('SELECT * FROM hosts ORDER BY id DESC').fetchall()
    for h in hosts:
        pw = decrypt(h['password'])
        label = f"{h['username']}@{h['address']}"
        try:
            out = ssh_exec(h['address'], h['username'], pw, PRESET_CMDS[action], timeout=20)
        except Exception as e:
            out = f"Fehler: {e}"
        log_entry(label, f"{action} (all)", out)
    with db() as conn:
        log = [dict(id=r['id'], timestamp=r['at'], host=r['host'], command=r['command'], output=r['output']) for r in conn.execute('SELECT * FROM session_log ORDER BY id DESC LIMIT 60').fetchall()][::-1]
    return render_template('session_log.html', session_log=log)

if __name__ == '__main__':
    bind = os.environ.get('APP_BIND','127.0.0.1')
    port = int(os.environ.get('APP_PORT','8080'))
    app.run(host=bind, port=port, debug=False)
