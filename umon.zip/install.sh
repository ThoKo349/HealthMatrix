
#!/usr/bin/env bash
# Umon installer (supports local run or remote fetch of umon.zip from GitHub)
set -euo pipefail

REPO_OWNER="ThoKo349"
REPO_NAME="HealthMatrix"
ZIP_URL="https://github.com/${REPO_OWNER}/${REPO_NAME}/raw/main/umon.zip"

SERVICE_NAME="umon.service"
APP_DIR="/opt/umon"
ETC_DIR="/etc/umon"
DATA_DIR="/var/lib/umon"
LOG_DIR="/var/log/umon"
APP_USER="umon"
PORT="8080"

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing dependency: $1"; exit 1; }
}

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (sudo)." ; exit 1
fi

apt-get update
apt-get install -y python3 python3-venv python3-pip unzip curl

# Create user and dirs
id -u "$APP_USER" &>/dev/null || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_DIR" "$ETC_DIR" "$DATA_DIR" "$LOG_DIR"

# Detect if we're running from the project root (have app/ and requirements.txt)
if [[ -d "./app" && -f "./requirements.txt" ]]; then
  echo "Installing from current directory..."
  rsync -a --delete ./ "$APP_DIR/"
else
  echo "Fetching umon.zip from ${ZIP_URL} ..."
  TMP_ZIP="/tmp/umon.zip"
  curl -L "$ZIP_URL" -o "$TMP_ZIP"
  unzip -o "$TMP_ZIP" -d "$APP_DIR"
fi

# Python venv & deps
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

# Default config
if [[ ! -f "$ETC_DIR/config.yaml" ]]; then
  cat > "$ETC_DIR/config.yaml" <<'YML'
title: "HealthMatrix – Umon"
scheduler_interval_seconds: 30

targets:
  - name: Google DNS
    type: ping
    host: 8.8.8.8
    timeout: 2

  - name: Example Web
    type: http
    host: https://example.org
    timeout: 3

  - name: Local SSH
    type: tcp
    host: 127.0.0.1
    port: 22
    timeout: 2
YML
fi

# Systemd unit
cp "$APP_DIR/systemd/umon.service" "/etc/systemd/system/${SERVICE_NAME}"
sed -i "s|--port 8080|--port ${PORT}|" "/etc/systemd/system/${SERVICE_NAME}"

# Permissions
chown -R "$APP_USER":"$APP_USER" "$APP_DIR" "$DATA_DIR" "$LOG_DIR"
chmod 0755 "$APP_DIR" "$DATA_DIR" "$LOG_DIR"

# Enable & start
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

IP=$(hostname -I | awk '{print $1}')
echo
echo "✅ Installation complete."
echo "Open: http://$IP:${PORT}/"
echo "Config: /etc/umon/config.yaml"
echo "Logs:   journalctl -u umon -f"
