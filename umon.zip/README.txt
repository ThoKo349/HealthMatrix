# Umon – Self-hosted Monitoring App

This archive contains the full Umon monitoring system as defined in the ChatGPT project spec.

Unpack and upload contents to your GitHub repository root.
