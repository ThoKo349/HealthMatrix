
# Umon – Self-hosted Monitoring App (HealthMatrix)

Leichte Monitoring-Web-App (FastAPI) für Ubuntu-Server: Ping, HTTP, TCP, Host-Metriken.
Automatische Einrichtung via `install.sh` inkl. Python venv & systemd.

## Installation (Endnutzer)

**Variante A – ZIP direkt nutzen**
```bash
wget https://github.com/ThoKo349/HealthMatrix/raw/main/umon.zip
unzip umon.zip -d umon && cd umon
sudo bash install.sh
```

**Variante B – Einzeiler (Installer lädt ZIP selbst)**
```bash
curl -fsSL https://github.com/ThoKo349/HealthMatrix/raw/main/umon.zip -o /tmp/umon.zip   && mkdir -p /tmp/umon && unzip -o /tmp/umon.zip -d /tmp/umon && sudo bash /tmp/umon/install.sh
```

Nach der Installation:
- Aufruf: `http://<server-ip>:8080/`
- Logs: `journalctl -u umon -f`
- Konfiguration: `/etc/umon/config.yaml` (Targets anpassen) und dann `sudo systemctl restart umon`

## Systemd
- Unit: `/etc/systemd/system/umon.service`
- Service-Nutzer: `umon`
- Datenbank: `/var/lib/umon/umon.db`

## Sicherheit
- Reverse Proxy empfohlen, wenn öffentlich erreichbar.
- `UMON_SECRET_KEY` in der Unit anpassen.

## Lizenz
MIT
