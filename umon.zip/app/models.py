
from __future__ import annotations
from pydantic import BaseModel

class Health(BaseModel):
    ok: bool
    msg: str
