
from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Iterable, Any
from .config import DATA_DIR

DB_PATH = DATA_DIR / "umon.db"

def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

SCHEMA = """
CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts DATETIME DEFAULT CURRENT_TIMESTAMP,
    target TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    latency_ms REAL,
    info TEXT
);
CREATE INDEX IF NOT EXISTS idx_results_ts ON results(ts DESC);
"""

def init_db():
    with connect() as con:
        con.executescript(SCHEMA)

def insert_result(target: str, type_: str, status: str, latency_ms: float | None, info: str | None):
    with connect() as con:
        con.execute(
            "INSERT INTO results(target, type, status, latency_ms, info) VALUES(?,?,?,?,?)",
            (target, type_, status, latency_ms, info),
        )
        con.commit()

def latest_results(limit: int = 200):
    with connect() as con:
        cur = con.execute("SELECT * FROM results ORDER BY ts DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]
