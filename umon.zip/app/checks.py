
from __future__ import annotations
import asyncio
import shlex
import time
from typing import Tuple

import httpx

async def check_ping(host: str, timeout: float = 3.0) -> Tuple[str, float | None, str | None]:
    count = 1
    timeout_s = max(1, int(timeout))
    cmd = f"ping -c {count} -W {timeout_s} {shlex.quote(host)}"
    start = time.perf_counter()
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout + 1)
        except asyncio.TimeoutError:
            proc.kill()
            return ("DOWN", None, "ping timeout")
        ok = proc.returncode == 0
        latency = (time.perf_counter() - start) * 1000.0
        return ("UP" if ok else "DOWN", latency if ok else None, (stdout or stderr).decode(errors="ignore")[:400])
    except Exception as e:
        return ("DOWN", None, str(e))

async def check_http(url: str, timeout: float = 3.0) -> Tuple[str, float | None, str | None]:
    start = time.perf_counter()
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            r = await client.get(url)
        latency = (time.perf_counter() - start) * 1000.0
        if 200 <= r.status_code < 400:
            return ("UP", latency, f"HTTP {r.status_code}")
        return ("DOWN", latency, f"HTTP {r.status_code}")
    except Exception as e:
        return ("DOWN", None, str(e))

async def check_tcp(host: str, port: int, timeout: float = 3.0) -> Tuple[str, float | None, str | None]:
    start = time.perf_counter()
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=timeout)
        latency = (time.perf_counter() - start) * 1000.0
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        return ("UP", latency, "tcp connect ok")
    except Exception as e:
        return ("DOWN", None, str(e))
