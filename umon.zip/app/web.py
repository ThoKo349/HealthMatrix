
from __future__ import annotations
import asyncio
import psutil
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .config import load
from .db import init_db, latest_results
from .scheduler import scheduler_loop

app = FastAPI(title="Umon")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

@app.on_event("startup")
async def startup():
    init_db()
    cfg = load()
    asyncio.create_task(scheduler_loop(cfg.scheduler_interval_seconds))

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    cfg = load()
    results = latest_results(200)
    cpu = psutil.cpu_percent(interval=None)
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "cfg": cfg,
            "results": results,
            "cpu": cpu,
            "mem": vm,
            "disk": disk,
        },
    )

@app.get("/targets", response_class=HTMLResponse)
async def targets(request: Request):
    cfg = load()
    return templates.TemplateResponse("targets.html", {"request": request, "cfg": cfg})
