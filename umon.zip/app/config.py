
from __future__ import annotations
import os
from pathlib import Path
from typing import List, Optional, Literal
import yaml
from pydantic import BaseModel, Field

CONFIG_PATH = os.environ.get("UMON_CONFIG", "/etc/umon/config.yaml")
DATA_DIR = Path(os.environ.get("UMON_DATA_DIR", "/var/lib/umon"))
LOG_DIR = Path(os.environ.get("UMON_LOG_DIR", "/var/log/umon"))
SECRET_KEY = os.environ.get("UMON_SECRET_KEY", "CHANGE-ME")

class Target(BaseModel):
    name: str
    type: Literal["ping", "http", "tcp"]
    host: str
    port: Optional[int] = None
    timeout: float = 3.0

class Settings(BaseModel):
    title: str = "Umon"
    scheduler_interval_seconds: int = Field(default=30, ge=5, le=3600)
    targets: List[Target] = Field(default_factory=list)

_cached: Optional[Settings] = None

def load() -> Settings:
    global _cached
    if _cached:
        return _cached
    p = Path(CONFIG_PATH)
    if not p.exists():
        _cached = Settings()
        return _cached
    with p.open("r") as f:
        data = yaml.safe_load(f) or {}
    _cached = Settings(**data)
    return _cached
