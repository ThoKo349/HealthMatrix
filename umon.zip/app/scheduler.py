
from __future__ import annotations
import asyncio
from .config import load
from .db import insert_result
from . import checks

async def run_all_checks_once():
    cfg = load()
    tasks = []
    for t in cfg.targets:
        if t.type == "ping":
            tasks.append(_run("ping", t.name, checks.check_ping(t.host, t.timeout)))
        elif t.type == "http":
            tasks.append(_run("http", t.name, checks.check_http(t.host, t.timeout)))
        elif t.type == "tcp" and t.port:
            tasks.append(_run("tcp", t.name, checks.check_tcp(t.host, t.port, t.timeout)))
    await asyncio.gather(*tasks, return_exceptions=True)

async def _run(type_: str, target_name: str, coro):
    status, latency, info = await coro
    insert_result(target_name, type_, status, latency, info)

async def scheduler_loop(interval: int = 30, on_tick=None):
    while True:
        try:
            await run_all_checks_once()
            if on_tick:
                try:
                    on_tick()
                except Exception:
                    pass
        except Exception:
            pass
        await asyncio.sleep(interval)
